Hi there!

Thank you for trying out Aqua Pokitty. This game is based on Defender and Aqua Kitty by Tikipod! (Do check them out as the original is amazing!)

Information:
The purpose of this game is destroy the enemies on each level. Jelly fish will keep respawning while other enemies are on the level, as they keep trying to abduct your Milk station kitties under the water. You get bonuses for each kitty saved at the end of each level. For each milk station that remains active, you get extra points as the kitty pumps the milk to the ship above.

Some enemies just swim by, others follow you. Your bullets and their bullets only go a certain distance before disintegrating.
Pushing the A button fires the regular bullets. Pushing the B button fires power shots that are 3 times as powerful, but run out very quickly and you need to wait to replenish them.
D-pad moves your ship around the level.

You will notice a "cat-nav" on the bottom left of the screen. The yellow dot is your ship. The red dots are Jellies and a red dot with white circle shows a kitty being abducted. If you're close enough, you could kill the jelly to save the kitty, but be quick! If a kitty is abducted, that milk station is no longer active and you lose a life. You start with 5 lives and each enemy you destroy could potentially drop an item. An item could be a heart (extra life), a crystal (bonus) and a bomb (blows up all ships on your viewport).

If you like this game, please let us know! More of our games can be found at http://blackjet.co.uk - this game was made during October 2019.

Thanks for playing!

Regards,
Jaco